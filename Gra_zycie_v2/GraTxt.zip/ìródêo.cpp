#include<iostream>
#include"GraTxt.h"

int main() {
	GraTxt G(10, 20);
	G.ustawWartosc(0, 0, 1);
	G.ustawWartosc(1, 1, 1);
	G.start("dane.in",5);
}