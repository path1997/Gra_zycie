#include "Komorka.h"



Komorka::Komorka()
{
	stan = 0;
}

Komorka::~Komorka()
{
}



