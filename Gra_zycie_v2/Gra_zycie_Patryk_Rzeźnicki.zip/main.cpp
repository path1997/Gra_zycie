#include"GraTxt.h"

int main() {
	GraTxt G(10, 20);
	G.ustawWartosc(1, 0);
	G.start("dane.in",100);
	
}